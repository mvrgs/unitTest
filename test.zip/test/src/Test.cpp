#include "../ext/googletest/googletest/include/gtest/gtest.h"
#include "../include/MyFunctions.h"


TEST (Suma, Prueba)
{
    EXPECT_EQ(10, sum(5,5));
    EXPECT_EQ(50, sum (20,30));
}

TEST (Suma, PruebaCero)
{
    EXPECT_EQ(10, sum(10,0));
}
int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}